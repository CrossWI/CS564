SELECT COUNT(*)
FROM Users
WHERE Location = 'New York';