SELECT COUNT(*)
FROM Users
WHERE isSeller = 1 AND Rating > 1000;