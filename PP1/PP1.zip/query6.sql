SELECT COUNT(*)
FROM Users
WHERE isSeller = 1 AND isBidder = 1;